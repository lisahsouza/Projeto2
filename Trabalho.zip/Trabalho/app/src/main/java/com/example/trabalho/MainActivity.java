package com.example.trabalho;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button botao = (Button) findViewById(R.id.bt_calcular);
        final EditText consumo = (EditText) findViewById(R.id.edt_consumo);
        final EditText couvert = (EditText) findViewById(R.id.edt_couvert_artistico);
        final EditText dividir = (EditText) findViewById(R.id.edt_dividir);
        final EditText taxa = (EditText) findViewById(R.id.edt_servico);
        final EditText conta = (EditText) findViewById(R.id.edt_conta_total);
        final EditText pessoa = (EditText) findViewById(R.id.edt_valor_pessoa);


        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double consu = Double.parseDouble(consumo.getText().toString());
                Double porcentagem = 10/100*consu;
                taxa.setText(""+porcentagem);

                Double conver = Double.parseDouble(couvert.getText().toString());
                Double contatotal = consu + porcentagem + conver;
                conta.setText(""+contatotal);

                int divid = Integer.parseInt(dividir.getText().toString());
                Double porpes = contatotal/divid;
                pessoa.setText(""+porpes);
            }
        });
    }
}
