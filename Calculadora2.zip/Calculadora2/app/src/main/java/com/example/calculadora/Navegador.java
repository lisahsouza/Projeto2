package com.example.calculadora;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.security.PrivateKey;

public class Navegador extends AppCompatActivity {
        private Button botaoPesquisa;
        private EditText textoURL;
        private WebView navegador;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navegador);

        botaoPesquisa = (Button) findViewById(R.id.botaoURL);
        textoURL = (EditText) findViewById(R.id.InserirURL);
        navegador = (WebView) findViewById(R.id.NavegadordaWeb);

        navegador.getSettings().setJavaScriptEnabled(true);
        navegador.setWebViewClient(new WebViewClient());

        botaoPesquisa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navegador.loadUrl(textoURL.getText().toString());
            }
        });


    }






}