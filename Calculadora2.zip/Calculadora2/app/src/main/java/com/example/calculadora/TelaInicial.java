package com.example.calculadora;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TelaInicial extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_inicial);

        Button btnCalculadora = (Button) findViewById(R.id.btCalculadora);
        btnCalculadora.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(TelaInicial.this,MainActivity.class);
                startActivity(it);

         Button btnNavegador = (Button) findViewById(R.id.btNavegador);
                btnNavegador.setOnClickListener(new View.OnClickListener() {

          public void onClick (View v)       {
                Intent it = new Intent(TelaInicial.this,Navegador.class)
                }

            }
        });

    }



    }


